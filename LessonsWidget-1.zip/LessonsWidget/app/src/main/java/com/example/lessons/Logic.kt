package com.example.lessons

import java.util.Calendar

data class Lesson(val day: Int?, val s: Int, val e: Int, val name: String) {
    val ss get() = "%02d:%02d".format(s / 60, s % 60)
    val ee get() = "%02d:%02d".format(e / 60, e % 60)
}

object Logic {
    private val days = listOf("вс", "пн", "вт", "ср", "чт", "пт", "сб")
    private val rx = Regex("""^\s*(?:(пн|вт|ср|чт|пт|сб|вс)\s+)?(\d{1,2}):(\d{2})\s*[-–]\s*(\d{1,2}):(\d{2})\s*(.*)$""", RegexOption.IGNORE_CASE)

    // Формат строки: [пн] 08:30-09:15 Предмет  (без дня = каждый день)
    fun parse(text: String): List<Lesson> = text.lines().mapNotNull { line ->
        val g = rx.find(line)?.groupValues ?: return@mapNotNull null
        Lesson(
            if (g[1].isEmpty()) null else days.indexOf(g[1].lowercase()),
            g[2].toInt() * 60 + g[3].toInt(), g[4].toInt() * 60 + g[5].toInt(),
            g[6].trim().ifEmpty { "Урок" }
        )
    }

    fun status(all: List<Lesson>, showNext: Boolean, showBreaks: Boolean): Pair<String, String> {
        val c = Calendar.getInstance()
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val dow = c.get(Calendar.DAY_OF_WEEK) - 1
        val L = all.filter { (it.day == null || it.day == dow) && it.e > it.s }.sortedBy { it.s }
        if (L.isEmpty()) return "Сегодня уроков нет" to ""
        val i = L.indexOfFirst { m >= it.s && m < it.e }
        if (i >= 0) {
            val l = L[i]; val nx = L.getOrNull(i + 1)
            val t = "Урок: ${l.name}  ${l.ss}–${l.ee}"
            val b = "Осталось ${l.e - m} мин" + if (showNext && nx != null) " · Дальше: ${nx.name} (${nx.ss})" else ""
            return t to b
        }
        val nx = L.firstOrNull { it.s > m }
        val pv = L.lastOrNull { it.e <= m }
        return when {
            nx != null && pv != null ->
                if (showBreaks) "Перемена ${pv.ee}–${nx.ss}" to "Будет: ${nx.name} (${nx.ss}–${nx.ee}) · через ${nx.s - m} мин"
                else "Дальше: ${nx.name}" to "${nx.ss}–${nx.ee}"
            nx != null -> "Уроки начнутся в ${nx.ss}" to "${nx.name} · через ${nx.s - m} мин"
            else -> "Уроки закончились" to ""
        }
    }
}
