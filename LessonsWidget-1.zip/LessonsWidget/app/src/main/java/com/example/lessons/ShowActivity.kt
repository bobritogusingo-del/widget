package com.example.lessons

import android.app.Activity
import android.content.*
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.TextView

// Плавающее окно поверх экрана блокировки. Закрывается тапом мимо, через N секунд или при разблокировке.
class ShowActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var tv: TextView
    private var left = 10
    private val loop = object : Runnable {
        override fun run() {
            val p = getSharedPreferences("p", 0)
            val (t, b) = Logic.status(Logic.parse(p.getString("text", "") ?: ""), p.getBoolean("next", true), p.getBoolean("brk", true))
            tv.text = "$t\n$b".trim()
            if (--left <= 0) finish() else h.postDelayed(this, 1000)
        }
    }
    private val closer = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { finish() } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setShowWhenLocked(true); setTurnScreenOn(true)
        left = getSharedPreferences("p", 0).getInt("secs", 10).coerceIn(3, 120)
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.setGravity(Gravity.TOP)
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setFinishOnTouchOutside(true)
        tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; setPadding(48, 36, 48, 36)
            background = GradientDrawable().apply { setColor(0xEE1C2541.toInt()); cornerRadius = 48f }
            setOnClickListener { finish() }
        }
        setContentView(tv)
        registerReceiver(closer, IntentFilter().apply { addAction(Intent.ACTION_USER_PRESENT); addAction(Intent.ACTION_SCREEN_OFF) })
        h.post(loop)
    }

    override fun onDestroy() { h.removeCallbacks(loop); try { unregisterReceiver(closer) } catch (_: Exception) {}; super.onDestroy() }
}
