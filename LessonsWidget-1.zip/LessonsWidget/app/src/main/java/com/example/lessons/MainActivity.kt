package com.example.lessons

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = getSharedPreferences("p", 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { root.addView(it) }
        fun chk(t: String, k: String, d: Boolean) = CheckBox(this).apply { text = t; isChecked = p.getBoolean(k, d)
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean(k, v).apply() } }.also { root.addView(it) }

        root.addView(TextView(this).apply { text = "Расписание. Одна строка = один урок:\n08:30-09:15 Математика\nпн 09:25-10:10 Физика  (с днём недели)"; textSize = 14f })
        val et = EditText(this).apply { minLines = 10; gravity = android.view.Gravity.TOP
            setText(p.getString("text", "08:30-09:15 Математика\n09:25-10:10 Русский язык\n10:30-11:15 Физика")) }
        root.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        chk("Показывать следующий урок", "next", true)
        chk("Показывать перемены", "brk", true)
        chk("Окно на экране блокировки при включении экрана", "lockpopup", true)
        root.addView(TextView(this).apply { text = "Сколько секунд держать окно:" })
        val secs = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(p.getInt("secs", 10).toString()) }
        root.addView(secs)

        btn("Сохранить и запустить") {
            p.edit().putString("text", et.text.toString()).putInt("secs", secs.text.toString().toIntOrNull() ?: 10).apply()
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            startForegroundService(Intent(this, WidgetService::class.java))
        }
        btn("Остановить") { stopService(Intent(this, WidgetService::class.java)) }
        btn("1. Разрешить «Поверх других окон» (обязательно)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("Проверить окно сейчас") { startActivity(Intent(this, ShowActivity::class.java)) }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
