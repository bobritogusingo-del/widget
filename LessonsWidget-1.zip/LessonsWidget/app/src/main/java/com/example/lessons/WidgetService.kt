package com.example.lessons

import android.app.*
import android.app.KeyguardManager
import android.content.*
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.WindowManager

// Фоновый сервис: обновляет уведомление и, когда включается экран на блокировке, показывает окно с уроком.
class WidgetService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var dot: android.view.View? = null
    private val loop = object : Runnable { override fun run() { update(); h.postDelayed(this, 15000) } }

    private val screenOn = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val p = getSharedPreferences("p", 0)
            val locked = getSystemService(KeyguardManager::class.java).isKeyguardLocked
            if (p.getBoolean("lockpopup", true) && locked && Settings.canDrawOverlays(c))
                startActivity(Intent(c, ShowActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("l", "Расписание", NotificationManager.IMPORTANCE_LOW)
            .apply { lockscreenVisibility = Notification.VISIBILITY_SECRET })
        startForeground(1, build("Расписание", "Работает"))
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try { unregisterReceiver(screenOn) } catch (_: Exception) {}
        registerReceiver(screenOn, IntentFilter(Intent.ACTION_SCREEN_ON))
        addDot()
        h.removeCallbacks(loop); h.post(loop)
        return START_STICKY
    }

    // Невидимое окно 1x1 пиксель: на новых Android оно нужно, чтобы система разрешила открыть окно из фона.
    private fun addDot() {
        if (dot != null || !Settings.canDrawOverlays(this)) return
        val v = android.view.View(this)
        val l = WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        try { wm.addView(v, l); dot = v } catch (_: Exception) {}
    }

    private fun build(t: String, b: String) = Notification.Builder(this, "l")
        .setSmallIcon(android.R.drawable.ic_menu_recent_history)
        .setContentTitle(t).setContentText(b.ifEmpty { " " })
        .setOngoing(true).setOnlyAlertOnce(true).setVisibility(Notification.VISIBILITY_SECRET)
        .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        .build()

    private fun update() {
        addDot()
        val p = getSharedPreferences("p", 0)
        val (t, b) = Logic.status(Logic.parse(p.getString("text", "") ?: ""), p.getBoolean("next", true), p.getBoolean("brk", true))
        getSystemService(NotificationManager::class.java).notify(1, build(t, b))
    }

    override fun onDestroy() {
        h.removeCallbacks(loop)
        try { unregisterReceiver(screenOn) } catch (_: Exception) {}
        dot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
